--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.9
-- Dumped by pg_dump version 9.6.9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_email_unique;
ALTER TABLE ONLY public.user_shopping_cart DROP CONSTRAINT user_shopping_cart_pkey;
ALTER TABLE ONLY public.roles DROP CONSTRAINT roles_pkey;
ALTER TABLE ONLY public."references" DROP CONSTRAINT references_pkey;
ALTER TABLE ONLY public.products DROP CONSTRAINT products_pkey;
ALTER TABLE ONLY public.product_galleries DROP CONSTRAINT product_galleries_pkey;
ALTER TABLE ONLY public.product_feature_images DROP CONSTRAINT product_feature_images_pkey;
ALTER TABLE ONLY public.product_category_relation DROP CONSTRAINT product_category_relation_pkey;
ALTER TABLE ONLY public.product_categories DROP CONSTRAINT product_categories_pkey;
ALTER TABLE ONLY public.product_categories DROP CONSTRAINT product_categories_name_unique;
ALTER TABLE ONLY public.posts DROP CONSTRAINT posts_pkey;
ALTER TABLE ONLY public.post_galleries DROP CONSTRAINT post_galleries_pkey;
ALTER TABLE ONLY public.post_category_relation DROP CONSTRAINT post_category_relation_pkey;
ALTER TABLE ONLY public.post_categories DROP CONSTRAINT post_categories_pkey;
ALTER TABLE ONLY public.post_categories DROP CONSTRAINT post_categories_name_unique;
ALTER TABLE ONLY public.migrations DROP CONSTRAINT migrations_pkey;
ALTER TABLE ONLY public.media__files DROP CONSTRAINT media__files_pkey;
ALTER TABLE ONLY public.guest_shopping_cart DROP CONSTRAINT guest_shopping_cart_pkey;
ALTER TABLE ONLY public.guest_info DROP CONSTRAINT guest_info_pkey;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.user_shopping_cart ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.roles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."references" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.product_galleries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.product_feature_images ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.product_category_relation ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.product_categories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.posts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.post_galleries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.post_category_relation ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.post_categories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.migrations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.media__files ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.guest_shopping_cart ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.guest_info ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP SEQUENCE public.user_shopping_cart_id_seq;
DROP TABLE public.user_shopping_cart;
DROP SEQUENCE public.roles_id_seq;
DROP TABLE public.roles;
DROP SEQUENCE public.references_id_seq;
DROP TABLE public."references";
DROP SEQUENCE public.products_id_seq;
DROP TABLE public.products;
DROP SEQUENCE public.product_galleries_id_seq;
DROP TABLE public.product_galleries;
DROP SEQUENCE public.product_feature_images_id_seq;
DROP TABLE public.product_feature_images;
DROP SEQUENCE public.product_category_relation_id_seq;
DROP TABLE public.product_category_relation;
DROP SEQUENCE public.product_categories_id_seq;
DROP TABLE public.product_categories;
DROP SEQUENCE public.posts_id_seq;
DROP TABLE public.posts;
DROP SEQUENCE public.post_galleries_id_seq;
DROP TABLE public.post_galleries;
DROP SEQUENCE public.post_category_relation_id_seq;
DROP TABLE public.post_category_relation;
DROP SEQUENCE public.post_categories_id_seq;
DROP TABLE public.post_categories;
DROP SEQUENCE public.migrations_id_seq;
DROP TABLE public.migrations;
DROP SEQUENCE public.media__files_id_seq;
DROP TABLE public.media__files;
DROP SEQUENCE public.guest_shopping_cart_id_seq;
DROP TABLE public.guest_shopping_cart;
DROP SEQUENCE public.guest_info_id_seq;
DROP TABLE public.guest_info;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: bipham
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO bipham;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: bipham
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: guest_info; Type: TABLE; Schema: public; Owner: bipham
--

CREATE TABLE public.guest_info (
    id integer NOT NULL,
    ip character varying(255) NOT NULL,
    device text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.guest_info OWNER TO bipham;

--
-- Name: guest_info_id_seq; Type: SEQUENCE; Schema: public; Owner: bipham
--

CREATE SEQUENCE public.guest_info_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.guest_info_id_seq OWNER TO bipham;

--
-- Name: guest_info_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bipham
--

ALTER SEQUENCE public.guest_info_id_seq OWNED BY public.guest_info.id;


--
-- Name: guest_shopping_cart; Type: TABLE; Schema: public; Owner: bipham
--

CREATE TABLE public.guest_shopping_cart (
    id integer NOT NULL,
    guest_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity integer NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.guest_shopping_cart OWNER TO bipham;

--
-- Name: guest_shopping_cart_id_seq; Type: SEQUENCE; Schema: public; Owner: bipham
--

CREATE SEQUENCE public.guest_shopping_cart_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.guest_shopping_cart_id_seq OWNER TO bipham;

--
-- Name: guest_shopping_cart_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bipham
--

ALTER SEQUENCE public.guest_shopping_cart_id_seq OWNED BY public.guest_shopping_cart.id;


--
-- Name: media__files; Type: TABLE; Schema: public; Owner: bipham
--

CREATE TABLE public.media__files (
    id integer NOT NULL,
    filename character varying(255) NOT NULL,
    path_org character varying(255) NOT NULL,
    path_medium character varying(255),
    path_small character varying(255),
    extension character varying(255),
    mime_type character varying(255) NOT NULL,
    file_size character varying(255) NOT NULL,
    folder_id integer NOT NULL,
    external_link text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    type character varying(255) DEFAULT 'images'::character varying NOT NULL
);


ALTER TABLE public.media__files OWNER TO bipham;

--
-- Name: COLUMN media__files.path_org; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.media__files.path_org IS 'Path to original image file.';


--
-- Name: COLUMN media__files.path_medium; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.media__files.path_medium IS 'Path to medium image file.';


--
-- Name: COLUMN media__files.path_small; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.media__files.path_small IS 'Path to small image file.';


--
-- Name: COLUMN media__files.extension; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.media__files.extension IS 'File type (extension file type).';


--
-- Name: COLUMN media__files.external_link; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.media__files.external_link IS 'Link external media';


--
-- Name: COLUMN media__files.type; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.media__files.type IS 'type of media';


--
-- Name: media__files_id_seq; Type: SEQUENCE; Schema: public; Owner: bipham
--

CREATE SEQUENCE public.media__files_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.media__files_id_seq OWNER TO bipham;

--
-- Name: media__files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bipham
--

ALTER SEQUENCE public.media__files_id_seq OWNED BY public.media__files.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: bipham
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO bipham;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: bipham
--

CREATE SEQUENCE public.migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO bipham;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bipham
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: post_categories; Type: TABLE; Schema: public; Owner: bipham
--

CREATE TABLE public.post_categories (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    parent_id integer DEFAULT 0 NOT NULL,
    slug character varying(255),
    "desc" text,
    "order" integer,
    meta_title text,
    meta_keywords text,
    meta_description text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.post_categories OWNER TO bipham;

--
-- Name: COLUMN post_categories.parent_id; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.post_categories.parent_id IS 'Id of category parent';


--
-- Name: COLUMN post_categories.slug; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.post_categories.slug IS 'Slug of category';


--
-- Name: COLUMN post_categories."desc"; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.post_categories."desc" IS 'desc';


--
-- Name: COLUMN post_categories."order"; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.post_categories."order" IS 'Order of this category (Just on the same level).';


--
-- Name: COLUMN post_categories.meta_title; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.post_categories.meta_title IS 'SEO title';


--
-- Name: COLUMN post_categories.meta_keywords; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.post_categories.meta_keywords IS 'SEO meta_keywords';


--
-- Name: COLUMN post_categories.meta_description; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.post_categories.meta_description IS 'SEO description';


--
-- Name: post_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: bipham
--

CREATE SEQUENCE public.post_categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.post_categories_id_seq OWNER TO bipham;

--
-- Name: post_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bipham
--

ALTER SEQUENCE public.post_categories_id_seq OWNED BY public.post_categories.id;


--
-- Name: post_category_relation; Type: TABLE; Schema: public; Owner: bipham
--

CREATE TABLE public.post_category_relation (
    id integer NOT NULL,
    post_id integer NOT NULL,
    cate_id integer NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.post_category_relation OWNER TO bipham;

--
-- Name: post_category_relation_id_seq; Type: SEQUENCE; Schema: public; Owner: bipham
--

CREATE SEQUENCE public.post_category_relation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.post_category_relation_id_seq OWNER TO bipham;

--
-- Name: post_category_relation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bipham
--

ALTER SEQUENCE public.post_category_relation_id_seq OWNED BY public.post_category_relation.id;


--
-- Name: post_galleries; Type: TABLE; Schema: public; Owner: bipham
--

CREATE TABLE public.post_galleries (
    id integer NOT NULL,
    post_id integer NOT NULL,
    media_id integer NOT NULL,
    "order" integer NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.post_galleries OWNER TO bipham;

--
-- Name: post_galleries_id_seq; Type: SEQUENCE; Schema: public; Owner: bipham
--

CREATE SEQUENCE public.post_galleries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.post_galleries_id_seq OWNER TO bipham;

--
-- Name: post_galleries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bipham
--

ALTER SEQUENCE public.post_galleries_id_seq OWNED BY public.post_galleries.id;


--
-- Name: posts; Type: TABLE; Schema: public; Owner: bipham
--

CREATE TABLE public.posts (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    "desc" text NOT NULL,
    content text NOT NULL,
    is_publish boolean DEFAULT true NOT NULL,
    at_homepage boolean DEFAULT false NOT NULL,
    rating integer DEFAULT 0 NOT NULL,
    view integer DEFAULT 0 NOT NULL,
    meta_keywords text,
    type_article integer,
    created_by integer DEFAULT 1 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    meta_title text,
    meta_description text
);


ALTER TABLE public.posts OWNER TO bipham;

--
-- Name: COLUMN posts.is_publish; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.posts.is_publish IS 'true: Published, false: Draft';


--
-- Name: COLUMN posts.at_homepage; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.posts.at_homepage IS 'Show post in homepage';


--
-- Name: COLUMN posts.rating; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.posts.rating IS 'Number of star for this product.';


--
-- Name: COLUMN posts.view; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.posts.view IS 'Number of viewed for this product.';


--
-- Name: COLUMN posts.meta_keywords; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.posts.meta_keywords IS 'SEO meta_keywords';


--
-- Name: COLUMN posts.type_article; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.posts.type_article IS 'Reference Gallery | Slide | Video | Audio';


--
-- Name: COLUMN posts.meta_title; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.posts.meta_title IS 'SEO title';


--
-- Name: COLUMN posts.meta_description; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.posts.meta_description IS 'SEO description';


--
-- Name: posts_id_seq; Type: SEQUENCE; Schema: public; Owner: bipham
--

CREATE SEQUENCE public.posts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.posts_id_seq OWNER TO bipham;

--
-- Name: posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bipham
--

ALTER SEQUENCE public.posts_id_seq OWNED BY public.posts.id;


--
-- Name: product_categories; Type: TABLE; Schema: public; Owner: bipham
--

CREATE TABLE public.product_categories (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    parent_id integer DEFAULT 0 NOT NULL,
    slug character varying(255),
    "desc" text,
    "order" integer,
    meta_title text,
    meta_keywords text,
    meta_description text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.product_categories OWNER TO bipham;

--
-- Name: COLUMN product_categories.parent_id; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.product_categories.parent_id IS 'Id of category parent';


--
-- Name: COLUMN product_categories.slug; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.product_categories.slug IS 'Slug of category';


--
-- Name: COLUMN product_categories."desc"; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.product_categories."desc" IS 'desc';


--
-- Name: COLUMN product_categories."order"; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.product_categories."order" IS 'Order of this category (Just on the same level).';


--
-- Name: COLUMN product_categories.meta_title; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.product_categories.meta_title IS 'SEO title';


--
-- Name: COLUMN product_categories.meta_keywords; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.product_categories.meta_keywords IS 'SEO meta_keywords';


--
-- Name: COLUMN product_categories.meta_description; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.product_categories.meta_description IS 'SEO description';


--
-- Name: product_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: bipham
--

CREATE SEQUENCE public.product_categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_categories_id_seq OWNER TO bipham;

--
-- Name: product_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bipham
--

ALTER SEQUENCE public.product_categories_id_seq OWNED BY public.product_categories.id;


--
-- Name: product_category_relation; Type: TABLE; Schema: public; Owner: bipham
--

CREATE TABLE public.product_category_relation (
    id integer NOT NULL,
    product_id integer NOT NULL,
    cate_id integer NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.product_category_relation OWNER TO bipham;

--
-- Name: product_category_relation_id_seq; Type: SEQUENCE; Schema: public; Owner: bipham
--

CREATE SEQUENCE public.product_category_relation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_category_relation_id_seq OWNER TO bipham;

--
-- Name: product_category_relation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bipham
--

ALTER SEQUENCE public.product_category_relation_id_seq OWNED BY public.product_category_relation.id;


--
-- Name: product_feature_images; Type: TABLE; Schema: public; Owner: bipham
--

CREATE TABLE public.product_feature_images (
    id integer NOT NULL,
    product_id integer NOT NULL,
    media_id integer NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.product_feature_images OWNER TO bipham;

--
-- Name: product_feature_images_id_seq; Type: SEQUENCE; Schema: public; Owner: bipham
--

CREATE SEQUENCE public.product_feature_images_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_feature_images_id_seq OWNER TO bipham;

--
-- Name: product_feature_images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bipham
--

ALTER SEQUENCE public.product_feature_images_id_seq OWNED BY public.product_feature_images.id;


--
-- Name: product_galleries; Type: TABLE; Schema: public; Owner: bipham
--

CREATE TABLE public.product_galleries (
    id integer NOT NULL,
    product_id integer NOT NULL,
    media_id integer NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.product_galleries OWNER TO bipham;

--
-- Name: product_galleries_id_seq; Type: SEQUENCE; Schema: public; Owner: bipham
--

CREATE SEQUENCE public.product_galleries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_galleries_id_seq OWNER TO bipham;

--
-- Name: product_galleries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bipham
--

ALTER SEQUENCE public.product_galleries_id_seq OWNED BY public.product_galleries.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: bipham
--

CREATE TABLE public.products (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    sku character varying(255) NOT NULL,
    "desc" text NOT NULL,
    long_desc text,
    is_publish boolean DEFAULT true NOT NULL,
    is_feature boolean DEFAULT false NOT NULL,
    is_best_seller boolean DEFAULT false NOT NULL,
    is_free_ship boolean DEFAULT false NOT NULL,
    price integer NOT NULL,
    sale_price integer,
    in_stock integer,
    manager_stock boolean DEFAULT false NOT NULL,
    allow_order boolean DEFAULT false NOT NULL,
    rating integer DEFAULT 0 NOT NULL,
    meta_keywords text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    meta_title text,
    meta_description text,
    "order" integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.products OWNER TO bipham;

--
-- Name: COLUMN products."desc"; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.products."desc" IS 'desc';


--
-- Name: COLUMN products.long_desc; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.products.long_desc IS 'long_desc';


--
-- Name: COLUMN products.is_publish; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.products.is_publish IS 'true: Published, false: Draft';


--
-- Name: COLUMN products.is_feature; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.products.is_feature IS 'Product feature';


--
-- Name: COLUMN products.is_best_seller; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.products.is_best_seller IS 'Product is best seller';


--
-- Name: COLUMN products.is_free_ship; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.products.is_free_ship IS 'Product is free ship';


--
-- Name: COLUMN products.price; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.products.price IS 'Original price';


--
-- Name: COLUMN products.sale_price; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.products.sale_price IS 'Sale Price';


--
-- Name: COLUMN products.in_stock; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.products.in_stock IS 'Total items in stock';


--
-- Name: COLUMN products.manager_stock; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.products.manager_stock IS 'Admin manager items in stock';


--
-- Name: COLUMN products.allow_order; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.products.allow_order IS 'Allow order product when stock not available';


--
-- Name: COLUMN products.rating; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.products.rating IS 'Number of star for this product.';


--
-- Name: COLUMN products.meta_keywords; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.products.meta_keywords IS 'SEO meta_keywords';


--
-- Name: COLUMN products.meta_title; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.products.meta_title IS 'SEO title';


--
-- Name: COLUMN products.meta_description; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.products.meta_description IS 'SEO description';


--
-- Name: COLUMN products."order"; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public.products."order" IS 'Order Product';


--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: bipham
--

CREATE SEQUENCE public.products_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_id_seq OWNER TO bipham;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bipham
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: references; Type: TABLE; Schema: public; Owner: bipham
--

CREATE TABLE public."references" (
    id integer NOT NULL,
    type character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    value character varying(255) NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    code character varying(255),
    is_publish boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public."references" OWNER TO bipham;

--
-- Name: COLUMN "references".is_publish; Type: COMMENT; Schema: public; Owner: bipham
--

COMMENT ON COLUMN public."references".is_publish IS 'true: Published';


--
-- Name: references_id_seq; Type: SEQUENCE; Schema: public; Owner: bipham
--

CREATE SEQUENCE public.references_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.references_id_seq OWNER TO bipham;

--
-- Name: references_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bipham
--

ALTER SEQUENCE public.references_id_seq OWNED BY public."references".id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: bipham
--

CREATE TABLE public.roles (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    permissions text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.roles OWNER TO bipham;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: bipham
--

CREATE SEQUENCE public.roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO bipham;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bipham
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: user_shopping_cart; Type: TABLE; Schema: public; Owner: bipham
--

CREATE TABLE public.user_shopping_cart (
    id integer NOT NULL,
    user_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity integer NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.user_shopping_cart OWNER TO bipham;

--
-- Name: user_shopping_cart_id_seq; Type: SEQUENCE; Schema: public; Owner: bipham
--

CREATE SEQUENCE public.user_shopping_cart_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_shopping_cart_id_seq OWNER TO bipham;

--
-- Name: user_shopping_cart_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bipham
--

ALTER SEQUENCE public.user_shopping_cart_id_seq OWNED BY public.user_shopping_cart.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: bipham
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    username character varying(255) NOT NULL,
    first_name character varying(255),
    last_name character varying(255),
    mid_name character varying(255),
    email character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    role_id bigint,
    avatar_link character varying(255),
    dob date,
    permissions text,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.users OWNER TO bipham;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: bipham
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO bipham;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bipham
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: guest_info id; Type: DEFAULT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.guest_info ALTER COLUMN id SET DEFAULT nextval('public.guest_info_id_seq'::regclass);


--
-- Name: guest_shopping_cart id; Type: DEFAULT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.guest_shopping_cart ALTER COLUMN id SET DEFAULT nextval('public.guest_shopping_cart_id_seq'::regclass);


--
-- Name: media__files id; Type: DEFAULT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.media__files ALTER COLUMN id SET DEFAULT nextval('public.media__files_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: post_categories id; Type: DEFAULT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.post_categories ALTER COLUMN id SET DEFAULT nextval('public.post_categories_id_seq'::regclass);


--
-- Name: post_category_relation id; Type: DEFAULT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.post_category_relation ALTER COLUMN id SET DEFAULT nextval('public.post_category_relation_id_seq'::regclass);


--
-- Name: post_galleries id; Type: DEFAULT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.post_galleries ALTER COLUMN id SET DEFAULT nextval('public.post_galleries_id_seq'::regclass);


--
-- Name: posts id; Type: DEFAULT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.posts ALTER COLUMN id SET DEFAULT nextval('public.posts_id_seq'::regclass);


--
-- Name: product_categories id; Type: DEFAULT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.product_categories ALTER COLUMN id SET DEFAULT nextval('public.product_categories_id_seq'::regclass);


--
-- Name: product_category_relation id; Type: DEFAULT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.product_category_relation ALTER COLUMN id SET DEFAULT nextval('public.product_category_relation_id_seq'::regclass);


--
-- Name: product_feature_images id; Type: DEFAULT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.product_feature_images ALTER COLUMN id SET DEFAULT nextval('public.product_feature_images_id_seq'::regclass);


--
-- Name: product_galleries id; Type: DEFAULT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.product_galleries ALTER COLUMN id SET DEFAULT nextval('public.product_galleries_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: references id; Type: DEFAULT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public."references" ALTER COLUMN id SET DEFAULT nextval('public.references_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: user_shopping_cart id; Type: DEFAULT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.user_shopping_cart ALTER COLUMN id SET DEFAULT nextval('public.user_shopping_cart_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: guest_info; Type: TABLE DATA; Schema: public; Owner: bipham
--

\i $$PATH$$/3252.dat

--
-- Name: guest_info_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bipham
--

SELECT pg_catalog.setval('public.guest_info_id_seq', 16, true);


--
-- Data for Name: guest_shopping_cart; Type: TABLE DATA; Schema: public; Owner: bipham
--

\i $$PATH$$/3250.dat

--
-- Name: guest_shopping_cart_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bipham
--

SELECT pg_catalog.setval('public.guest_shopping_cart_id_seq', 33, true);


--
-- Data for Name: media__files; Type: TABLE DATA; Schema: public; Owner: bipham
--

\i $$PATH$$/3226.dat

--
-- Name: media__files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bipham
--

SELECT pg_catalog.setval('public.media__files_id_seq', 92, true);


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: bipham
--

\i $$PATH$$/3220.dat

--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bipham
--

SELECT pg_catalog.setval('public.migrations_id_seq', 24, true);


--
-- Data for Name: post_categories; Type: TABLE DATA; Schema: public; Owner: bipham
--

\i $$PATH$$/3238.dat

--
-- Name: post_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bipham
--

SELECT pg_catalog.setval('public.post_categories_id_seq', 2, true);


--
-- Data for Name: post_category_relation; Type: TABLE DATA; Schema: public; Owner: bipham
--

\i $$PATH$$/3242.dat

--
-- Name: post_category_relation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bipham
--

SELECT pg_catalog.setval('public.post_category_relation_id_seq', 73, true);


--
-- Data for Name: post_galleries; Type: TABLE DATA; Schema: public; Owner: bipham
--

\i $$PATH$$/3244.dat

--
-- Name: post_galleries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bipham
--

SELECT pg_catalog.setval('public.post_galleries_id_seq', 111, true);


--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: bipham
--

\i $$PATH$$/3240.dat

--
-- Name: posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bipham
--

SELECT pg_catalog.setval('public.posts_id_seq', 4, true);


--
-- Data for Name: product_categories; Type: TABLE DATA; Schema: public; Owner: bipham
--

\i $$PATH$$/3228.dat

--
-- Name: product_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bipham
--

SELECT pg_catalog.setval('public.product_categories_id_seq', 9, true);


--
-- Data for Name: product_category_relation; Type: TABLE DATA; Schema: public; Owner: bipham
--

\i $$PATH$$/3230.dat

--
-- Name: product_category_relation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bipham
--

SELECT pg_catalog.setval('public.product_category_relation_id_seq', 82, true);


--
-- Data for Name: product_feature_images; Type: TABLE DATA; Schema: public; Owner: bipham
--

\i $$PATH$$/3236.dat

--
-- Name: product_feature_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bipham
--

SELECT pg_catalog.setval('public.product_feature_images_id_seq', 72, true);


--
-- Data for Name: product_galleries; Type: TABLE DATA; Schema: public; Owner: bipham
--

\i $$PATH$$/3234.dat

--
-- Name: product_galleries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bipham
--

SELECT pg_catalog.setval('public.product_galleries_id_seq', 72, true);


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: bipham
--

\i $$PATH$$/3232.dat

--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bipham
--

SELECT pg_catalog.setval('public.products_id_seq', 21, true);


--
-- Data for Name: references; Type: TABLE DATA; Schema: public; Owner: bipham
--

\i $$PATH$$/3246.dat

--
-- Name: references_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bipham
--

SELECT pg_catalog.setval('public.references_id_seq', 5, true);


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: bipham
--

\i $$PATH$$/3224.dat

--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bipham
--

SELECT pg_catalog.setval('public.roles_id_seq', 1, true);


--
-- Data for Name: user_shopping_cart; Type: TABLE DATA; Schema: public; Owner: bipham
--

\i $$PATH$$/3248.dat

--
-- Name: user_shopping_cart_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bipham
--

SELECT pg_catalog.setval('public.user_shopping_cart_id_seq', 1, true);


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: bipham
--

\i $$PATH$$/3222.dat

--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bipham
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: guest_info guest_info_pkey; Type: CONSTRAINT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.guest_info
    ADD CONSTRAINT guest_info_pkey PRIMARY KEY (id);


--
-- Name: guest_shopping_cart guest_shopping_cart_pkey; Type: CONSTRAINT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.guest_shopping_cart
    ADD CONSTRAINT guest_shopping_cart_pkey PRIMARY KEY (id);


--
-- Name: media__files media__files_pkey; Type: CONSTRAINT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.media__files
    ADD CONSTRAINT media__files_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: post_categories post_categories_name_unique; Type: CONSTRAINT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.post_categories
    ADD CONSTRAINT post_categories_name_unique UNIQUE (name);


--
-- Name: post_categories post_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.post_categories
    ADD CONSTRAINT post_categories_pkey PRIMARY KEY (id);


--
-- Name: post_category_relation post_category_relation_pkey; Type: CONSTRAINT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.post_category_relation
    ADD CONSTRAINT post_category_relation_pkey PRIMARY KEY (id);


--
-- Name: post_galleries post_galleries_pkey; Type: CONSTRAINT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.post_galleries
    ADD CONSTRAINT post_galleries_pkey PRIMARY KEY (id);


--
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- Name: product_categories product_categories_name_unique; Type: CONSTRAINT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_name_unique UNIQUE (name);


--
-- Name: product_categories product_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_pkey PRIMARY KEY (id);


--
-- Name: product_category_relation product_category_relation_pkey; Type: CONSTRAINT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.product_category_relation
    ADD CONSTRAINT product_category_relation_pkey PRIMARY KEY (id);


--
-- Name: product_feature_images product_feature_images_pkey; Type: CONSTRAINT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.product_feature_images
    ADD CONSTRAINT product_feature_images_pkey PRIMARY KEY (id);


--
-- Name: product_galleries product_galleries_pkey; Type: CONSTRAINT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.product_galleries
    ADD CONSTRAINT product_galleries_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: references references_pkey; Type: CONSTRAINT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public."references"
    ADD CONSTRAINT references_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: user_shopping_cart user_shopping_cart_pkey; Type: CONSTRAINT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.user_shopping_cart
    ADD CONSTRAINT user_shopping_cart_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: bipham
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: bipham
--

REVOKE ALL ON SCHEMA public FROM rdsadmin;
REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO bipham;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

